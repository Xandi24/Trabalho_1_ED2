/*
Alunos [No USP]: 
Vitor Alexandre Garcia Vaz [14611432]
Vitor Pardini Saconi [14611800]
*/


#include <stdio.h>
#include <stdlib.h>
#include <time.h>

FILE* arq;

void gerador_caso_teste(FILE* arquivo,int comando){
    
    srand(time(NULL));
    
    char nome[30];
    int qnt=0;
    int *vetor;
    int aux=0;
    int flag=1;


    printf("\nDigite o nome do arquivo[diretorio/numero de caso.txt]:\n"); 
    scanf("%s",nome);

    printf("Quantidade de elementos:"); scanf("%d",&qnt);
    vetor=calloc(qnt,sizeof(int));

    //Gera uma sequencia crescente[de 1 ate qnt ] de números em um vetor 
    if(comando==1){
        for(int i=0;i<qnt;i++){
            vetor[i]=i+1;
        }
    }

    //Gera uma sequencia crescente[de qnt ate 1 ] de números em um vetor 
    else if(comando==2){
        
        for(int i=qnt;i>0;i--){
            vetor[qnt-i]=i;
        }
    }
    
    //Gera uma sequencia de numeros aleatorios sem nenhuma repeticao
    else if(comando==3){
        
        for(int i=0;i<qnt;i++){
            printf("%d",i);
            flag=1;
            aux=rand()%qnt;
            
            //verifica se o numero gerado ja existe no vetor
            for(int j=0;j<i;j++){
                if(aux==vetor[j]) flag=0;
            }
            //evita que o numero ja existente seja adicionado
            if(flag==0){
                i--;
                continue;
            }
            //adiciona no vetor caso nao seja repetido
            else vetor[i]=aux;
    
        }
    }

    //Gera uma sequencia de numeros aleatorios com repeticao
    else if(comando==4){
        for(int i=0;i<qnt;i++){
            vetor[i]=rand()%qnt;
        }
    }

    //Regisra os elementos do vetor no arquivo [qnt + sequencia de numeros]
    arquivo=fopen(nome,"wt");
    fprintf(arquivo,"%d\n",qnt);
    for(int i=0;i<qnt;i++){
        fprintf(arquivo,"%d ",vetor[i]);
    }

    fclose(arquivo);


}

int main(){
    int comando;
    for(;;){

        //Menu do usuario
        printf("\t\tComandos:\n\t1-ordem crescente\n\t2-ordem decrescente\n\t3-aleatorios\n\t4-aleatorios com repeticao\n\tOutro-sair\nComando:");
        scanf("%d",&comando);

        if(comando<1 || comando>4) break;
        
        //Gera um caso teste conforme o comando do usuario
        gerador_caso_teste(arq,comando);
        
    }
    return 0;
}