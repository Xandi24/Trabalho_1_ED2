/*
Alunos [No USP]: 
Vitor Alexandre Garcia Vaz [14611432]
Vitor Pardini Saconi [14611800]
*/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

FILE *arq;

int* bubble_sort(vetor ,tamanho)
int *vetor; int tamanho;
{
    //Flag que sinaliza 1 enquanto o vetor não está ordenado.
    int flag=1;

    //Auxiliar usado para trocas de valores entre elementos do vetor.
    int aux=0;
    
    //Copia vetor para não alterar vetor original
    int *vtr;
    vtr=calloc(tamanho,sizeof(int));
    for(int i=0;i<tamanho;i++){
            vtr[i]=vetor[i];
    }

    while(flag){
        /* 
            Se nao houver troca, a flag continua zerada, sinalizando 
            que o vetor está ordenado.
        */
        flag=0;

        for(int i=0;i<(tamanho-1);i++){
            
            if(vtr[i]>vtr[i+1]){
                /* 
                Se o elemento atual for maior que o proximo elemento, os valores 
                entre eles são trocados e a flag continua igual a um, ou seja, 
                houve troca de valores e o vetor ainda não esta ordenado crescentemente.
                */
                aux=vtr[i+1];
                vetor[i+1]=vtr[i];
                vtr[i]=aux;
                flag=1;
            }
        }
    }

    return vtr;
}

double tempo_execucao(arquivo,nome)
FILE *arquivo; char *nome;
{
    int i=0;
    double tempo;

    int a=0;
    int *vetor=NULL;
    int *aux=NULL;

    arquivo=fopen(nome,"rt");
    
    /* Abertura do arquivo do respectivo arquivo de teste para 
    leitura, permitindo saber o tamanho do vetor a ser alocado
    e a gravação dos elementos no vetor*/
    if(arquivo!=NULL){
        
        fscanf(arquivo,"%d\n",&a);
        vetor=calloc(a,sizeof(int));

        while(!feof(arquivo)){
            
            fscanf(arquivo,"%d ",&vetor[i]);
            i++;
        }
    }

    else{
    
        printf("\n\t Erro na abertura do arquivo %s",nome);
        return -1;
    }

    fclose(arquivo);
    
    /*  Declaração de variavel usada para obter o tempo de execucao
    por meio da biblioteca time.h   */
    clock_t t;

    for(int i=0;i<10;i++){
        t=clock();
        aux=bubble_sort(vetor,a);
        t=clock()-t;
        //obtem o tempo de 10 processamentos em segundos
        tempo = tempo + ((double)t)/CLOCKS_PER_SEC;
    }
    
    //obtem a media dos tempos de processamento
    tempo=tempo/10;

    //retorna o tempo medio de processamento em ms
    return (tempo*1000);   
}

int main(){
    
    //Exposicao dos dados numericos.
    printf("\t Tempo de execução para vetor [ordenado crescentemente] para n entradas:\n");
    printf(" n=100: %lf ms\n",tempo_execucao(arq,"../casos_teste/1.txt"));
    printf(" n=500: %lf ms\n",tempo_execucao(arq,"../casos_teste/5.txt"));
    printf(" n=1000: %lf ms\n",tempo_execucao(arq,"../casos_teste/9.txt"));
    printf(" n=5000: %lf ms\n",tempo_execucao(arq,"../casos_teste/13.txt"));
    printf(" n=10000: %lf ms\n",tempo_execucao(arq,"../casos_teste/17.txt"));

    printf("\n\t Tempo de execução para vetor [ordenado decrescentemente] para n entradas:\n");
    printf(" n=100: %lf ms\n",tempo_execucao(arq,"../casos_teste/2.txt"));
    printf(" n=500: %lf ms\n",tempo_execucao(arq,"../casos_teste/6.txt"));
    printf(" n=1000: %lf ms\n",tempo_execucao(arq,"../casos_teste/10.txt"));
    printf(" n=5000: %lf ms\n",tempo_execucao(arq,"../casos_teste/14.txt"));
    printf(" n=10000: %lf ms\n",tempo_execucao(arq,"../casos_teste/18.txt"));

    printf("\n\tTempo de execução para vetor [com elementos aleatorios] para n entradas:\n");
    printf(" n=100: %lf ms\n",tempo_execucao(arq,"../casos_teste/3.txt"));
    printf(" n=500: %lf ms\n",tempo_execucao(arq,"../casos_teste/7.txt"));
    printf(" n=1000: %lf ms\n",tempo_execucao(arq,"../casos_teste/11.txt"));
    printf(" n=5000: %lf ms\n",tempo_execucao(arq,"../casos_teste/15.txt"));
    printf(" n=10000: %lf ms\n",tempo_execucao(arq,"../casos_teste/19.txt"));

    printf("\n\tTempo de execução para vetor [com elementos aleatorios e com repetidos] para n entradas:\n");
    printf(" n=100: %lf ms\n",tempo_execucao(arq,"../casos_teste/4.txt"));
    printf(" n=500: %lf ms\n",tempo_execucao(arq,"../casos_teste/8.txt"));
    printf(" n=1000: %lf ms\n",tempo_execucao(arq,"../casos_teste/12.txt"));
    printf(" n=5000: %lf ms\n",tempo_execucao(arq,"../casos_teste/16.txt"));
    printf(" n=10000: %lf ms\n",tempo_execucao(arq,"../casos_teste/20.txt"));

    return 0;
}



